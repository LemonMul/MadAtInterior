import { View, Text } from 'react-native'
import React from 'react'

export default function bookmark() {
  return (
    <View>
      <Text>bookmark</Text>
    </View>
  )
}