import { View, Text } from 'react-native'
import React from 'react'

export default function compass() {
  return (
    <View>
      <Text>compass</Text>
    </View>
  )
}