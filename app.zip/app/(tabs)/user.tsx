import { View, Text } from 'react-native'
import React from 'react'

export default function user() {
  return (
    <View>
      <Text>user</Text>
    </View>
  )
}